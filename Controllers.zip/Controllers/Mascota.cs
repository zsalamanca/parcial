﻿using System;
using System.Collections.Generic;

namespace Veterinaria.Controllers
{
    public partial class Mascota
    {
        public int Idmascotas { get; set; }
        public string? Nombre { get; set; }
        public string? Raza { get; set; }
        public string? Color { get; set; }
    }
}
